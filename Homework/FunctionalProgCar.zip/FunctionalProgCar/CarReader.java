import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
// import java.nio.file.SecureDirectoryStream;
import java.util.ArrayList;
// import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * A class to read CSV-style list of Apples. Adapted from the original.
 * 
 * @author David J. Barnes and Michael Kölling
 * @version 2023.02.13
 */
public class CarReader {
    // How many fields are expected.
    private static final int NUMBER_OF_FIELDS = 5;
    // Index values for the fields in each record.
    private static final int ID = 0,
            WEIGHT = 1,
            BRAND = 2,
            RATING = 3,
            ELEC = 4;

    /**
     * Create a CarReader.
     */
    public CarReader() {
    }

    /**
     * Read sightings in CSV format from the given file.
     * Return an ArrayList of Sighting objects created from
     * the information in the file.
     * 
     * @param filename The file to be read - should be in CSV format.
     * @return A list of Cars.
     */
    public ArrayList<Car> getCars(String filename) {
        // Create a Apple from a CSV input line.
        Function<String, Car> createSighting = record -> {
            String[] parts = record.split(",");
            if (parts.length == NUMBER_OF_FIELDS) {
                try {
                    int id = Integer.parseInt(parts[ID].trim());
                    double weight = Double.parseDouble(parts[WEIGHT].trim());
                    String brand = parts[BRAND].trim();
                    int rating = Integer.parseInt(parts[RATING].trim());
                    boolean isElectric = Boolean.parseBoolean(parts[ELEC].trim());
                    return new Car(weight, brand, rating, isElectric);
                } catch (NumberFormatException e) {
                    return null;
                }
            } else {
                return null;
            }
        };
        ArrayList<Car> cars;
        try {
            cars = Files.lines(Paths.get(filename))
                    .filter(record -> record.length() > 0 && record.charAt(0) != '#')
                    .map(createSighting)
                    .filter(sighting -> sighting != null)
                    .collect(Collectors.toCollection(ArrayList::new));
        } catch (IOException e) {
            // System.out.println("Unable to open " + filename);
            cars = new ArrayList<>();
        }
        return cars;
    }

}
