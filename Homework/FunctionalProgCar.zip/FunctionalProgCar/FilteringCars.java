import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
// import java.util.stream.Collectors;

/**
 * Demo of functional programming.
 *
 * @author Team Java
 * @version Feb 27 2023
 */
public class FilteringCars {
    private ArrayList<Car> cars;

    /**
     * Create an AppleFilter.
     */
    public FilteringCars() {
        CarReader reader = new CarReader();
        this.cars = reader.getCars("carList.csv"); // reads in data from CSV
    }

    public List<Car> filter(Predicate<Car> p) {
        List<Car> result = new ArrayList<>();
        for (Car car : cars) {
            if (p.test(car)) {
                result.add(car);
            }
        }
        printList(result);
        return result;
    }

    /**
     * Prints a given list of apples on output.
     * 
     * @param appleList List of apples that you want to print.
     */
    private void printList(List<Car> carList) {
        System.out.println("List of Car: ");
        for (Car car : carList) {
            System.out.println(" - " + car);
        }
        System.out.println("Filtered list length: " + carList.size());
    }

}