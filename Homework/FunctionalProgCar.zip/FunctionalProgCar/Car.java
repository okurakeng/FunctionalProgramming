public class Car {
    private double weight = 0;
    private String brand = "";
    private int rating = 0;
    private boolean isElectric = false;

    public Car(Double weight, String brand, int rating, boolean isElectric) {
        this.weight = weight;
        this.brand = brand;
        this.rating = rating;
        this.isElectric = isElectric;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public boolean getIsElectric() {
        return isElectric;
    }

    public void setIsElectric(boolean isElectric) {
        this.isElectric = isElectric;
    }

    public String toString() {
        return "Car{" +
                "brand='" + brand + '\'' +
                ", weight=" + weight +
                ", rating=" + rating +
                ", isElectric=" + isElectric +
                '}';
    }
}
