public class Student {
    private double gpa = 0;
    private String major = "";
    private int numClasses = 0;
    private boolean isMasters = false;

    public Student(Double gpa, String major, int numClasses, boolean isMasters) {
        this.gpa = gpa;
        this.major = major;
        this.numClasses = numClasses;
        this.isMasters = isMasters;
    }

    public Double getGPA() {
        return gpa;
    }

    public void setGPA(Double gpa) {
        this.gpa = gpa;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public int getNumClasses() {
        return numClasses;
    }

    public void setNumClasses(int numClasses) {
        this.numClasses = numClasses;
    }

    public boolean getIsMasters() {
        return isMasters;
    }

    public void setIsMasters(boolean isMasters) {
        this.isMasters = isMasters;
    }

    public String toString() {
        return "Car{" +
                "major='" + major + '\'' +
                ", gpa=" + gpa +
                ", numClasses=" + numClasses +
                ", isMasters=" + isMasters +
                '}';
    }
}
