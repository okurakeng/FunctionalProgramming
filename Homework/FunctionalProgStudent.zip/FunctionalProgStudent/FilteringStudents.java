import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * Demo of functional programming.
 *
 * @author Team Java
 * @version Feb 27 2023
 */
public class FilteringStudents {
    private ArrayList<Student> students;

    /**
     * Create an FilteringStudent.
     */
    public FilteringStudents() {
        StudentReader reader = new StudentReader();
        this.students = reader.getStudents("studentList.csv"); // reads in data from CSV
    }

    public List<Student> filter(Predicate<Student> p) {
        List<Student> result = new ArrayList<>();
        for (Student student : students) {
            if (p.test(student)) {
                result.add(student);
            }
        }
        printList(result);
        return result;
    }

    /**
     * Prints a given list of apples on output. Nothing fancy...yet.
     * 
     * @param appleList List of apples that you want to print.
     */
    public void printList(List<Student> studentList) {
        System.out.println("List of Students: ");
        for (Student student : studentList) {
            System.out.println(" - " + student);
        }
        System.out.println("Filtered list length: " + studentList.size());
    }

}